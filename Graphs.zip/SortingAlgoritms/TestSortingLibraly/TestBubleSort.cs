﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using SortingLibrary;

namespace TestSortingLibraly
{
    [TestClass]
    public class TestBubleSort
    {
        [TestMethod]
        public void TestSort()
        {
            int[] arrayToSort = { 1, 5, 2, 3 };
            int[] expectedOrder = { 1, 2, 3, 5 };

            int[] actualOrder = BubbleSort.Sort(arrayToSort);

            Assert.IsTrue(Arrays.DeepEqual(expectedOrder,actualOrder));
        }
    }
}
