﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortingLibrary
{
    public class BubbleSort
    {
        public static int[] Sort(int[] arrayToSort)
        {
            for (int i = 0; i < arrayToSort.Length-1; i++)
            {
                for (int j = 0; j < arrayToSort.Length-1; j++)
                {
                    if (arrayToSort[j] > arrayToSort[j + 1])
                    {
                        int tmp = arrayToSort[j];
                        arrayToSort[j] = arrayToSort[j + 1];
                        arrayToSort[j + 1] = tmp;
                    }
                }
            }
            return arrayToSort;
        }

        
    }
}
