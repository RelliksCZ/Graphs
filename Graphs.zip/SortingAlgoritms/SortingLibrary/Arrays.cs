﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortingLibrary
{
    public class Arrays
    {
        public static int[] GetRandomArray(int size) 
        {
            Random generator = new Random();
            int[] randomArray = new int[size];

            for (int i = 0; i < randomArray.Length; i++)
            {
                randomArray[i] = generator.Next();
            }
            return randomArray;
        }
        public static bool DeepEqual(int[] first, int[] second) 
        {
            if (first.Length != second.Length)
            {
                return false;
            }
            for (int i = 0; i < first.Length; i++)
            {
                if (first[i] != second[i])
                {
                    return false;
                }
            }
            return true;
        }
        public static int[] GetArrayFromConsole()
        {
            return null;
        }
    }
}
