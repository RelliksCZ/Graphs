﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SortingLibrary;
using ConsoleChartLibrary;
using System.Drawing;

namespace SortingConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] values = { 2, 3, 1, 5, 3, 2, 1, 4, 2, 1, 5 };
            double[] values1 = { 2, 3, 70, 22, 33, 55, 71, 37, 8, 12, 100 };

            BarChart Graph1 = new BarChart(values, 20, new Point(5, 15), "Grades", ConsoleColor.Red);
            BarChart Graph2 = new BarChart(values1, 20, new Point(50,15), "Random Graph", ConsoleColor.Green);
            Graph1.Draw();
            Graph2.Draw();
            Console.ReadKey();
        }
    }
}
