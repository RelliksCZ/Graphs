﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ConsoleChartLibrary
{
    public class BarChart
    {
        private int totalHeight;
        private Point offset;
        private double[] values;
        private string title;
        private ConsoleColor barColor;
        public  BarChart(double[] values, int totalHeight, Point offset, string title = "", ConsoleColor barColor = ConsoleColor.White) 
        {
            this.values = values;
            this.totalHeight = totalHeight;
            this.offset = offset;
            this.title = title;
            this.barColor = barColor;
        }
        public void Draw()
        {
            double maxValue = values.Max();
            int filledHeight;

            for (int i = 0; i < values.Length; i++)
            {
                filledHeight = (int)Math.Round((values[i] / maxValue) * totalHeight);
                DrawBar(filledHeight, i, barColor);
            }
            DrawTitle(title);
        }

        private void DrawBar(int filledHeight, int horizontalPosition, ConsoleColor barColor = ConsoleColor.White)
        {
            Console.BackgroundColor = barColor;

            for (int i = 0; i < totalHeight; i++)
            {
                if (i >= totalHeight - filledHeight)
                {
                    Console.SetCursorPosition(horizontalPosition + offset.X, i + offset.Y);
                    Console.Write(" ");
                }
            }
            Console.ResetColor();
            //DrawBarNumber(horizontalPosition);
        }
        private void DrawTitle(string title)
        {
            Console.SetCursorPosition(offset.X, offset.Y - 2);
            Console.Write(title);
        }
        private void DrawBarNumber(int horizontalPosition) 
        {
            int barNumber = horizontalPosition + 1;
            string textNumber = barNumber.ToString();
            
            for (int i = 0; i < textNumber.Length; i++)
            {
                Console.SetCursorPosition(offset.X + horizontalPosition, offset.Y + totalHeight + i);
                Console.Write(textNumber[i]);                
            }
            
        }
    }
}
